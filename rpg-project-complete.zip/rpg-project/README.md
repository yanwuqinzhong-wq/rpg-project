# 大陸戦記(仮) - RPG Project

UNDERTALE/DELTARUNE的な会話・ルート分岐重視の2D RPG。
オリジナル世界観「大陸戦記」(ルミナスの街から始まる物語)。

## 技術スタック

- HTML5 Canvas + JavaScript (ES6 Modules)
- ビルドツール不要。ブラウザで `index.html` を開くだけで動作。
- データはJSONで管理(データ駆動設計)。キャラクター・敵・クエスト追加時に
  コードを触らずJSONの追記だけで済むようにする。

## 起動方法

```
# ローカルサーバーが必要(fetchでJSONを読むため file:// 直開きは不可)
cd rpg-project
python3 -m http.server 8000
# ブラウザで http://localhost:8000 を開く
```

## 会話データ形式(Stage4)

`src/data/dialogues/*.json` はノードベースの分岐グラフ形式です。

- `entry`: 会話開始ノードを条件付きで決定(配列の先頭から評価し、最初に条件を満たしたものを採用。条件無しの項目は常に真=デフォルトのフォールバックとして末尾に置く)
- `nodes`: 各ノードは通常のセリフ(`speaker`/`text`/`next`)か、選択肢(`choices`)のどちらか
- `effects`: ノード到達時 or 選択肢決定時に即座に反映される。`flag`(EventManagerのフラグ設定)/`counter`(カウンター加算)/`affection`(好感度カウンター `affection_<id>` を加減算)の3種類に対応
- `next: null` で会話終了、呼び出し元のMapSceneへ復帰

新しい会話を追加する場合、`DialogueScene.js`のコードは一切変更不要で、JSONの追記のみで対応できます(データ駆動設計)。

## フォルダ構成

```
rpg-project/
├── index.html              # エントリーポイント(Canvas設置)
├── src/
│   ├── core/                # ゲーム基盤(疎結合の中心)
│   │   ├── Game.js          # メインループ・ブートストラップ
│   │   ├── SceneManager.js  # シーン切り替え(Title/Map/Battle/Dialogue)
│   │   ├── EventManager.js  # フラグ・カウンター一元管理(ルート分岐/好感度/実績)
│   │   ├── SaveManager.js   # セーブ/ロード(localStorage)
│   │   └── Input.js         # キーボード入力
│   ├── entities/            # キャラクター関連クラス
│   │   ├── Character.js     # 基底クラス(ステータス計算/レベルアップ/スキル解禁)
│   │   ├── Party.js         # パーティ編成(前衛/控え)
│   │   ├── Enemy.js         # 敵(Character継承、報酬/説得/ルート強化)
│   │   ├── SkillTree.js     # スキルツリー(前提条件付き解禁)
│   │   ├── StatusEffect.js  # 状態異常の基底クラス
│   │   └── MapPlayer.js     # マップ上のプレイヤーアバター(グリッド移動)
│   ├── map/                  # マップ機能
│   │   ├── TileMap.js       # タイル当たり判定
│   │   ├── NPC.js           # NPC配置・接触判定
│   │   └── EncounterZone.js # エンカウント範囲・発生率判定
│   ├── scenes/               # 各画面
│   │   ├── TitleScene.js
│   │   ├── MapScene.js      # フィールド表示・移動・NPC接触・エンカウント判定
│   │   ├── BattleScene.js   # 戦闘システム本実装(コマンド/対象選択のステートマシン)
│   │   └── DialogueScene.js # 会話システム本実装(選択肢/条件分岐/効果反映)
│   ├── battle/               # 戦闘システム本実装(Stage5)
│   │   ├── BattleSystem.js  # ターン順/行動実行/説得・逃走/勝敗判定/報酬
│   │   └── Skill.js         # skills.jsonを解釈する汎用スキルクラス
│   ├── ui/                   # UI部品本実装(Stage6)。全シーンがこれらに描画を委譲する
│   │   ├── UIManager.js      # パネル/バー/折り返しテキスト/メニュー一覧の静的描画関数群
│   │   ├── DialogueBox.js    # セリフの1文字ずつ表示演出(会話/戦闘メッセージ共用)
│   │   └── Menu.js           # 選択肢メニュー(カーソル移動+UIManagerへの描画委譲)
│   ├── quest/
│   │   └── QuestManager.js
│   ├── route/
│   │   └── RouteManager.js   # N/P/Gルート判定の集約ポイント(genocide_kills/persuaded_enemiesカウンターを参照)
│   ├── data/                 # データ駆動設計の核。JSON管理
│   │   ├── characters.json
│   │   ├── enemies.json
│   │   ├── skills.json       # スキル/魔法の効果定義(Skill.jsが解釈)
│   │   ├── quests.json
│   │   ├── maps/
│   │   │   └── luminas.json  # ルミナスのタイルマップ・NPC配置・エンカウント設定
│   │   └── dialogues/        # ノードベースの分岐会話データ
│   │       ├── riria_meet.json
│   │       ├── garon_intro.json
│   │       └── guild_receptionist_intro.json
│   └── utils/
│       ├── helpers.js
│       └── leveling.js       # 経験値カーブ・ステータス成長計算
└── assets/
    ├── images/
    ├── audio/
    └── maps/
```

## 設計方針

- **疎結合**: EventManagerがフラグの唯一の情報源(single source of truth)。
  各システムは互いを直接参照せず、EventManager経由でやり取りする。
- **データ駆動**: キャラクター・敵・クエスト・会話は全てJSON管理。
  新キャラ追加はJSON追記 + 必要ならクラス継承のみで対応可能。
- **シーン共通インターフェース**: 全シーンが `onEnter/update/render/onExit` を持ち、
  SceneManagerが均一に扱える。
- **ルート管理の集約**: N/P/Gルートの判定ロジックをRouteManagerに集約し、
  各シーンでのif分岐地獄を防ぐ。

## 開発ステージ(進行中)

- [x] 1. プロジェクト構成(起動確認: タイトル画面表示)
- [x] 2. コアシステム(ステータス計算/レベルアップ/スキルツリー/パーティ編成、動作確認済み)
- [x] 3. マップ(ルミナスのタイルマップ、移動、NPC接触、エンカウント判定、動作確認済み)
- [x] 4. イベント(会話システム本実装: 選択肢分岐/条件分岐/好感度・フラグ連動、動作確認済み)
- [x] 5. 戦闘(BattleSystem本実装: ターン制/攻撃/魔法・スキル/せっとく/ぼうぎょ/にげる、動作確認済み)
- [x] 6. UI(UIManager/DialogueBox/Menuへ描画を統合、被弾フラッシュ演出、ゲームオーバー画面、マップのパーティステータスメニューを追加、動作確認済み)
- [x] 7. セーブ(SaveManagerとUIの接続: マップのXメニューからセーブ、タイトルからつづきから読込、動作確認済み)
- [x] 8. クエスト(QuestManager本実装、ギルド受付嬢からクエスト掲示板を開いて受注/報告、ギルドランクE〜S、討伐カウンター式と直接挑戦式の2種類のクエストに対応、動作確認済み)
- [x] 9. ボス(中ボス2体+四皇4体+隠しボス1体にbaseStats/専用スキルを追加。ボスAI(スキル使用・HP低下時のぼうぎょ・第二形態変身)を実装。回復魔法(ヒール/サンクチュアリ)を新規追加してバランス調整、シミュレーションで全ボスの勝率を検証済み)
- [x] 10. エンディング(RouteManagerのN/P/G判定に基づくEndingSceneを追加。最終ボス撃破で自動遷移、動作確認済み)

## Stage8〜10 補足

- **クエスト**: `src/quest/QuestManager.js`。ギルドランクは達成クエスト数で自動算出(E→D→C→B→A→S)。
  討伐目標型(`objective.type:'defeat'`、ギルドに報告して完了)と、直接挑戦型
  (`objective.type:'battle'`、掲示板から即座にその敵との戦闘を開始し勝利で自動達成)の2種類。
  `requiredCounter`で虐殺数などの隠し条件付きクエストも表現できる(処刑人戦がこれに該当)。
- **ボス**: `aiPattern:'boss'`の敵はスキルツリー経由で専用スキルを使用し、HPが低い時は時々ぼうぎょも選ぶ。
  `hasSecondForm:true`のボス(ディアボロス/処刑人)はHP40%以下で一度だけ強化変身する。
- **エンディング**: `src/scenes/EndingScene.js`。`finalBoss:true`のクエスト(ディアボロス討伐/処刑人討伐)を
  達成した瞬間にBattleSceneから直接遷移する。
- **回復魔法**: これまでゲーム内にHP回復手段が一切存在せず、ボス戦が理論上クリア不可能だったため、
  リリアに「ヒール」(Lv1〜)「サンクチュアリ」(Lv10〜、全体回復)を追加した。

各ステージ完了ごとに動作確認してから次に進みます。

## 戦闘システム(Stage5)

- `src/battle/BattleSystem.js`: ターン順(spd基準、毎ラウンド再計算)/行動実行/説得・逃走/勝敗判定/経験値付与を担当。
- `src/battle/Skill.js`: `src/data/skills.json`のデータからダメージ計算・命中判定・会心・バフ付与を行う汎用クラス。新スキルはJSON追記のみで対応可能。
- `src/entities/StatusEffect.js`: `kind`(buff/debuff/stun/dot)とstatModsによるデータ駆動の状態異常/バフ基底クラス。
- `BattleScene.js`はコマンド選択(たたかう/まほう/せっとく/ぼうぎょ/にげる)→対象選択→結果メッセージのステートマシンで進行する。
- 「せっとく」はUNDERTALE的な対話決着の入り口。成功すると敵は`persuaded`扱いになり経験値対象外で戦闘から除外される。成功回数は`EventManager`の`persuaded_enemies`カウンターに、撃破数は`genocide_kills`カウンターに集計され、`RouteManager`のルート判定にそのまま使われる。
- ゲームオーバー画面(全滅時の専用`gameover`ステート、赤文字の「GAME OVER」演出)はStage6:UIで追加した。
  Stage5時点の暫定処置(即座に復活させてメッセージのみ表示)は置き換え済み。
- `Game.js`起動時に`characters.json`の3人(リリア/ガロン/セリア)を前衛へ加入させる暫定処理を追加(正式な会話イベント経由の加入は今後のイベント拡張で対応予定)。

## UI統合・演出強化(Stage6)

- `src/ui/UIManager.js`: パネル背景/HP・MPバー/折り返しテキスト/メニュー一覧描画を静的メソッド群として集約。
  BattleScene/DialogueScene/MapSceneで重複していた`ctx.fillRect`ベタ書きのコードをここに統一した。
  配色は`PALETTE`定数にまとめてあり、今後の配色調整は原則ここだけ触ればよい。
- `src/ui/DialogueBox.js`: セリフの1文字ずつ表示演出(reveal)とパネル描画を持つ部品。
  DialogueScene(通常会話)とBattleScene(戦闘メッセージログ)の両方がこれを共用する
  (BattleSceneはテンポを保つため`charsPerSecond`を通常会話より速めに設定)。
- `src/ui/Menu.js`: カーソル移動ロジックのみを持ち、描画は`UIManager.drawMenuList`へ委譲。
  `menu.render(ctx, x, y, uiOptions)`で列数(`rowsPerCol`)や行間を呼び出し側から指定できる。
- **被弾フラッシュ演出**: BattleSceneで攻撃/スキルが命中した対象(敵・味方とも)に白い点滅オーバーレイを
  短時間(0.25秒)重ねる。`BattleScene._markFlash`が行動実行前に対象を記録し、`_tickFlash`が毎フレーム
  残り時間を減算する、状態を持つ最小限のエフェクトシステム。
- **ゲームオーバー画面**: Stage5時点では全滅時に即座にパーティを復活させてメッセージを流すだけの暫定処理
  だったが、専用の`gameover`ステートと全画面演出(赤文字の「GAME OVER」+点滅ヒント)を追加した。
- **マップのパーティステータスメニュー**: MapSceneに`x`キーで開閉する簡易メニューを追加。
  `↑↓`でカーソル移動しながら、パーティ全員のLv/HP/MPを`UIManager.drawStatBlock`(BattleSceneの
  パーティ帯と共通の部品)で確認できる。装備やアイテムの参照はまだ無く、Stage7以降のセーブ/クエスト
  拡張に合わせて画面を増やしていく想定の土台。

## セーブ/ロード(Stage7)

- `src/core/SaveManager.js`: `localStorage`への永続化のみを担当する薄いレイヤー(スロット0〜2)。
  `save/load/hasSave/deleteSave/listSaves`のみを公開し、「ゲーム側の何を保存するか」は一切知らない。
- `Game.js`が「何を保存するか」を集約する: 現在のマップID・プレイヤー座標/向き・
  `Party#serialize()`・`EventManager#serialize()`をまとめて1つの状態オブジェクトにし、
  `saveGame(slot)`/`loadGame(slot)`として公開する。セーブはマップ上(戦闘/会話の外)でのみ可能。
- `Character#serialize()`/`applySaveData()`、`SkillTree#serialize()`/`deserialize()`、
  `EventManager#serialize()`/`deserialize()`は元々Stage2/4の時点で用意されていたAPIをそのまま利用。
  ロード時はcharacters.jsonのテンプレート(baseStats/成長率/スキルツリー定義)からCharacterを再構築し、
  そこへセーブ済みのlevel/exp/hp/mp/習得スキルを`applySaveData`で流し込む(テンプレート自体は保存しない)。
- `MapScene`の`X`メニューに「セーブ」を追加。スロット選択画面は`SaveManager.listSaves()`から
  日時とパーティ構成を`formatSaveSlotLabel`(`utils/helpers.js`)で一覧表示する。
- `TitleScene`に「はじめから/つづきから」を追加。「はじめから」は`Game#newGameParty()`で
  パーティとフラグ/カウンターを初期状態に戻し、「つづきから」はセーブスロットを選んで
  `Game#loadGame()`を呼ぶ。
- Node上での単体テストで、レベルアップ・スキル習得・HP変化・フラグ/カウンターを含む
  セーブ→ロードの往復が正しく復元されることを確認済み。

## 操作方法(Stage7時点)

- 矢印キー / WASD: 移動、戦闘中・メニュー中はコマンド/対象/カーソル選択の移動
- Z または Enter: 会話を進める・選択肢を決定 / 戦闘コマンド決定・メッセージ送り
- X: マップでメインメニュー(ステータス/セーブ)を開閉(Escでも閉じられる)
- タイトル画面: Enterでメニューを開き、「はじめから」または「つづきから」を選択
